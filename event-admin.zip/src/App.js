import React from 'react'
import './styles/style.min.css'
import Layout from './components/layout/Layout.js'
const App = () => {
  return (
    <>
      <Layout/>
    </>
  )
}

export default App