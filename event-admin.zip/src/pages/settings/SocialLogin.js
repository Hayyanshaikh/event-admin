import React from 'react'

const SocialLogin = () => {
	return (
		<div>
			SocialLogin
		</div>
	)
}

export default SocialLogin