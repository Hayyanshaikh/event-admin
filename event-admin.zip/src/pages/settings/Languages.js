import React from 'react'

const Languages = () => {
	return (
		<div>
			Languages
		</div>
	)
}

export default Languages