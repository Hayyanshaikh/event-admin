import React from 'react'

const General = () => {
	return (
		<div>
			General
		</div>
	)
}

export default General