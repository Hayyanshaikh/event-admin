import React from 'react'

const Permalink = () => {
	return (
		<div>
			Permalink
		</div>
	)
}

export default Permalink