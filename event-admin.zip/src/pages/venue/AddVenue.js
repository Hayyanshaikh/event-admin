import React from 'react'

const AddVenue = () => {
  return (
    <div>
      AddVenue
    </div>
  )
}

export default AddVenue